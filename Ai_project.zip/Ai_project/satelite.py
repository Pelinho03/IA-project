import torch
from torchvision import transforms, models
import cv2
import numpy as np

# Configurar dispositivo (GPU ou CPU)
device = 'cuda' if torch.cuda.is_available() else 'cpu'

# Carregar o modelo Faster R-CNN pré-treinado
model = models.detection.fasterrcnn_resnet50_fpn(pretrained=True)
model.eval()
model.to(device)

# Transformação da imagem para o formato aceito pelo modelo
transform = transforms.Compose([
    transforms.ToPILImage(),
    transforms.Resize((800, 800)),
    transforms.ToTensor(),
])

# Classes de exemplo para o modelo (adapte para o seu caso)
classes = ['_background_', 'plastico', 'nuvens', 'terra', 'mar']

# Função para realizar predições
def predict_image(image):
    # Aplicar transformações e enviar a imagem para o dispositivo
    image_tensor = transform(image).unsqueeze(0).to(device)

    # Fazer a predição com o modelo
    with torch.no_grad():
        outputs = model(image_tensor)

    # Extrair as caixas, labels e scores das detecções
    scores = outputs[0]['scores'].cpu().numpy()
    boxes = outputs[0]['boxes'].cpu().numpy()
    labels = outputs[0]['labels'].cpu().numpy()

    return boxes, labels, scores

# Inicializar captura de vídeo
cap = cv2.VideoCapture(0)

# Verificar se a câmera foi aberta com sucesso
if not cap.isOpened():
    print("Não foi possível acessar a câmera. Verifique as configurações.")
    exit()

print("Pressione 'q' para sair da detecção em tempo real.")
while True:
    ret, frame = cap.read()  # Ler frame da câmera
    if not ret:
        print("Erro ao capturar o frame. Saindo...")
        break

    # Realizar predição no frame capturado
    boxes, labels, scores = predict_image(frame)

    # Processar as detecções
    for box, label, score in zip(boxes, labels, scores):
        if score > 0.5:  # Filtrar detecções com confiança maior que 0.5
            x1, y1, x2, y2 = map(int, box)  # Converter coordenadas para inteiros

            # Verificar se a label está dentro do range de classes
            if label < len(classes):
                class_name = classes[label]

                # Desenhar a caixa delimitadora
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)

                # Inserir o texto com a classe e confiança
                cv2.putText(frame, f'{class_name}: {score:.2f}', (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    # Exibir o frame com as detecções
    cv2.imshow("Detecção em tempo real", frame)

    # Sair do loop ao pressionar 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Liberar recursos
cap.release()
cv2.destroyAllWindows()